# Shopping Cart  
A simple E-commerce website using Flask.
  
## Dependencies ##
1. Python3
2. Flask
3. Sqlite

## How to run ##
1. Set up database by running database.py
2. Run main.py
3. Enter localhost:5000 in the browser.
