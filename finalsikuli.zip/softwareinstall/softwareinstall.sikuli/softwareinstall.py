

type("r",KeyModifier.WIN)
path =r'D:\trainings\thales1\finalsikuli\softwareinstall'
type(path)
sleep(2)
type(Key.ENTER)
sleep(2)
doubleClick("1623738211567.png")

sleep(2)

click("1623738283540.png")

sleep(100)

#install_complete = '"1623738414707.png"

find("1623739269077.png").highlight(3)

click("1623738444529.png")