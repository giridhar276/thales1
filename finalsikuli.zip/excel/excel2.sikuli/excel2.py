
type("g", Key.CTRL)
sleep(2)
type("A1")
sleep(1)
type(Key.ENTER)
for val in range(1,10):
    #cell = "A" + str(val)
    type(str(val))
    sleep(1)
    type(Key.ENTER)