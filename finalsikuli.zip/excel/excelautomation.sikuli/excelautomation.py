
sleep(3)

type("g", Key.CTRL)
sleep(2)
type("B5")
sleep(2)
type(Key.ENTER)
sleep(2)
type("2")
sleep(2)
type(Key.TAB)
sleep(2)
type("4")
sleep(2)
type(Key.TAB)
sleep(2)
type("=B5+C5")
sleep(2)
type(Key.ENTER)




