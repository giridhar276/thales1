
# Start the browser and run the song
type(Key.WIN)
type("chrome https://www.youtube.com/watch?v=r01DOmPpxjg")
type(Key.ENTER)
sleep(2)
type(Key.ENTER)

# Pause the song
type(Key.SPACE)
sleep(2)

# Share and Copy the song
click("1623734704726.png")
sleep(2)
#click(Pattern().targetOffset(-18,3))
#print("*********************")
sleep(2)
click("1623734720428.png")
sleep(2)
print("*********************")
# Get the clipboard value (URL)
starting_point = Env.getClipboard()
print("*********************")
print(starting_point)
print("*********************")


#sleep(10)