


#############################################################
### Make sure to re-capture all images from your computer ###
#############################################################

type(Key.WIN)
sleep(2)
type("chrome https://www.amazon.in/")
sleep(2)
type(Key.ENTER)
sleep(2)

click(Pattern("1623743098431.png").similar(0.90).targetOffset(36,-4))
sleep(2)
type("software engineering books")
sleep(2)
type(Key.ENTER)
sleep(2)

click("1623743258104.png")
sleep(2)
click("1623743347877.png"    )
sleep(2)
type(Key.ENTER)
sleep(2)

#wait("AddedtoBaske.png", 10)
#find("AddedtoBaske.png").highlight(3)