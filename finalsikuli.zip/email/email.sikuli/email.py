
type(Key.WIN)
sleep(1)
type("chrome www.gmail.com")

type(Key.ENTER)
sleep(4)

click("1623736747161.png")
sleep(2)
type("giridhar276@gmail.com")
sleep(2)
type(Key.TAB)
sleep(1)
type(Key.TAB)
sleep(2)
type("[Subject] Resume")
sleep(2)
type(Key.TAB)
sleep(2)
body = '''
   Dear team,

   PFA the updated profile

   Regards,
   Giridhar Sripathi
   Research Scholar
   NIT Jamshedpur
'''
type(body)
sleep(2)

click("1623736859204.png")
sleep(2)
type(r"D:\resumes\Giridhar.docx")
sleep(2)
type(Key.ENTER)
sleep(3)

click("1623737043585.png")

find("1623737141194.png").highlight(5)