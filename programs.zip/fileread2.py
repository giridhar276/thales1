

import csv
 
with open("customers.txt","r") as fobj:
    ## convert fobj to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
        
        
## using pandas

import pandas 

df = pandas.read_csv("customers.txt")
print(df.head(3))