#4. Write a Python program to read realestate.csv and display the count of an individual city.

import csv
citylist = []
with open("realestate.csv") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        city = line[1]
        citylist.append(city)
        
    for city in set(citylist):
        print(city.ljust(25), citylist.count(city))
        

citydict = dict()
with open("realestate.csv") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        city = line[1]
        if city not in citydict:
            citydict[city] = 1
        else:
            citydict[city]+=1
        
    for city,value in citydict.items():
        print(city.ljust(25), value)