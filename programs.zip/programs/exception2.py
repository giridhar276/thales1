
try:
    fobj = open("customers.txt","r")
    for line in fobj:
        # remove whitespaces if having any
        line = line.strip()
        print(line)
    fobj.close()
    
    output = 1 + "hello"
    
except FileNotFoundError as err:
    print("User defined error :",'file not found')
    print("System error  :", err)
except TypeError as err:
    print("Invalid operation.. please check")
except (IndexError,KeyError) as err:
    print("Error found in list indexing or dictionary keys")
    print(err)

except Exception as error:
    print(error)
    
print("program begins from here again")