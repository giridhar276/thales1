import csv
cityset = set()
with open("realestate.csv") as fobj:
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        cityset.add(line[1])
    # displaying
    for city in cityset:
        print(city)

citylist = []
with open("realestate.csv") as fobj:
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        if city not in citylist:
            citylist.append(city)
    for city in citylist:
        print(city)
        
# using dictionary
citydict = dict()
with open("realestate.csv") as fobj:
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        # converting each city as dict key
        citydict[city] = 1
    for city in citydict:
        print(city)