

class Employee:
    def displayName(self):
        print("this is displayname()")
    def inputName(self):
        print("this is inputname()")
        

if __name__ == "__main__":
    # object creation or object initialization    
    emp1 = Employee()
    # calling methods
    emp1.displayName()
    emp1.inputName()
    
    
    emp2 = Employee()
    # calling methods
    emp2.displayName()
    emp2.inputName()
    emp3 = Employee()
    # calling methods
    emp3.displayName()
    emp3.inputName()