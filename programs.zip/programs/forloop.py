name  = "python"
for char in name:
    print(char)
    
alist = [10,20,30,40]
for val in alist:
    print(val)
    
atup = (10,3045,4)
for val in atup:
    print(val)

adict = {"chap1":10 ,"chap2":20}
for key in adict.keys():
    print(key)
    
for value in adict.values():
    print(value)
    
for key,value in adict.items():
    print(key,value)


aset= {10,10,20,30}
for item in aset:
    print(item)
    

for val in range(1,10):
    print(val)
    
    # range(start,stop,step)
for val in range(1,10,2):
    print(val)
    
    # range(start,stop,step)
for val in range(2,10,2):
    print(val)    
    
for val in range(10,0,-1):
    print(val)    
    