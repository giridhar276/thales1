import sys
import pymysql
try:
    # established the connection
    db = pymysql.connect(host ="localhost",port=3306,user='root1', password='india@123',database='realestateinfo')
    
    #print(db)
    # created the cursor for navigation
    cursor = db.cursor()
    # define your query
    query = "select * from realestate"
    # execute qurey
    cursor.execute(query)
    # 
    for record in cursor.fetchall():
        print("Street :", record[0])
        print("City   :", record[1])
        
    db.close()

except pymysql.InterfaceError as err:
    print(err)
except pymysql.DatabaseError as err:
    print(err)
except (pymysql.DataError, pymysql.OperationalError) as err:
    print(err)
except Exception as err:
    print("Error occured")
    print(err)
    print(sys.exc_info())