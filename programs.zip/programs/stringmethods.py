
## string methods

name = "python programming"

print(name.upper())
print(name.swapcase())
print(name.lower())

output = name.split(" ")
print(output)

print(name.isupper())

print(name.find("prog"))

print(name.center(40))
print(name.center(40,"*"))

string = "I love {} and {}"
print(string.format("python","ML"))
print(string.format(1,2))

print(name.replace("python","unix"))


if name.isupper() :
    print("String is defined in upper")
    print("Inside if")
    print("still inside if")
else:
    print("string is defined in lower")
    print("Inside else")
    print("still inside else")


if name.find("prog") != -1 :
    print("prog exists")
else:
    print("prog doesn't exist")
    
# in
if "prog" in name :
    print("Exists")
else:
    print("doesn't exist")


if name.count("prog") > 0 :
    print("exists")
else:
    print("doesn't exist")










