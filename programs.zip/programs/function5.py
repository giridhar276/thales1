def add(a,b):
    c = a + b
    return c

total = add(10,20)
print(total)



# functionname = lambda variables : expression

displayValues = lambda x,y : x + y
total = displayValues(10,20)



alist = [10,20,30,40]
# [15,25,35,45]

blist = []
for val in alist:
    blist.append(val + 5)
print(blist)

for val in alist:
    index = alist.index(val)
    alist[index] = val + 5
print(alist)    
    

## map(function,iterable)
alist = [10,20,30,40]
def increment(x):
    return x + 5
print(list(map(increment,alist)))



## map(function,iterable)
alist = [10,20,30,40]

increment = lambda x:x+5
print(list(map(increment,alist)))


## map(function,iterable)
alist = [10,20,30,40]
print(list(map(lambda x:x+5,alist)))


alist = ['10','29','30','40']
# [10,20,30,40]
print(list(map(lambda x: int(x) ,alist)))


alist = [1,2,3,4,5,6]
print(list(filter(lambda x : x%2 , alist)))


test = lambda x : True if ( x >10  and x <100) else False
print(test(10))


# list comprehension
alist = [10,20,30,40,50]
blist = [ x + 5   for x in alist]
print(blist)














