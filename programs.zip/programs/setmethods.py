

aset = {10,20,30,10,10,10,20}
bset = {30,40,50}

print("A set :", aset)
print("B set :", bset)

print(aset.union(bset))
print(aset.intersection(bset))
print(aset.difference(bset))
print(bset.difference(aset))
print(aset.issubset(bset))
print(bset.issubset(aset))

