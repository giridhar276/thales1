
from selenium import webdriver


browser = webdriver.Chrome()

url = "https://www.google.com"

browser.get(url)

browser.close()