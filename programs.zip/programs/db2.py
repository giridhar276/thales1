

import sys
import pymysql
try:
    # established the connection
    db = pymysql.connect(host ="localhost",port=3306,user='root', password='india@123',database='realestateinfo')
    
    #print(db)
    # created the cursor for navigation
    cursor = db.cursor()
    # define your query
    query = "insert into realestate values('{}','{}')".format('sector 10','Noida')
    # execute qurey
    cursor.execute(query)
    #print(cursor.rowcount ,"row inserted")
    db.commit()
    
    
    query = "select * from realestate" 
    cursor.execute(query)
    for record in cursor.fetchall():
        print("Street :", record[0])
        print("City   :", record[1])
           
    db.close()

except pymysql.InterfaceError as err:
    print(err)
except pymysql.DatabaseError as err:
    print(err)
except (pymysql.DataError, pymysql.OperationalError) as err:
    print(err)
except Exception as err:
    print("Error occured")
    print(err)
    print(sys.exc_info())