aset = {10,20,30,10,20}

print(aset)