
# keyword arguments

def display(second,third,first):
    print(first,second,third)

display(first = 10 , second = 20, third = 30)