
class Employee:
    def inputName(self,name):
        self.name = name
    def displayName(self):
        print("Employee's name :",self.name)        

# object creation or object initialization    
emp1 = Employee()
# calling methods

emp1.inputName("Rita")
emp1.displayName()

emp2 = Employee()
emp2.inputName("Gita")
emp2.displayName()
               