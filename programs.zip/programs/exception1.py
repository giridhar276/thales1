try:
    fobj = open("customers1.txt","r")
    for line in fobj:
        # remove whitespaces if having any
        line = line.strip()
        print(line)
    fobj.close()
except Exception as e:
    print("User defined error :",'file not found')
    print("System error  :", e)