fobj = open("customers.txt","w")

for val in range(1,11):
    fobj.write(str(val) + "\n")

fobj.close()




#fobj = open(r"D:\programs\customers.txt","w") # raw string
#fobj = open("D:/programs/customers.txt","w")

fobj = open("D:\\programs\\new\\customers.txt","wb")
for val in range(1,11):
    fobj.write(str(val) + "\n")
fobj.close()