alist = [10,20,30,40,50,50,60,60]

print(alist[0:3])

print(alist[::-1])


alist[0] = 1000

print("Updated list :", alist)



## tuple definition
atup = (10,20,30,40)
atup[0] = 2000
print("updated tuple :", atup)


# converting to the list first
alist = list(atup)
# making my changes
alist[0] = 2000
# reconverting back to tuple
atup = tuple(alist)
print("updated tuple :", atup)
