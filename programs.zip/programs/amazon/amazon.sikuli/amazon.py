
type(Key.WIN)
sleep(1)
type("chrome www.amazon.in")
type(Key.ENTER)
sleep(2)
#click("1623842570110.png")


click(Pattern("1623843667883.png").similar(0.90).targetOffset(36,-4))

sleep(1)
type("software enginnering book")

sleep(2)
type(Key.ENTER)

sleep(2)
click("1623842658018.png")
sleep(2)
click("1623842692800.png")
sleep(2)







