

book  = {"chap1":10 , "chap2":20 ,"chap3":30, "chap1":1000 } 

print(book)

## add new key:value pair to the dictionary
book["chap4"] = 40

print("After updating:", book)


print(list(book.keys()))
print(tuple(book.keys()))

print(list(book.values()))

print(book["chap1"])  # 10
#print(book["chap5"])  #

print(book.get("chap5"))  # None
print(book.get("chap4"))  # 40


print(list(book.items()))

book2 = {"chap6":60 ,"chap7":70,"chap2":200}

book.update(book2)  # book will be updated with book2
print(book)

#book2.update(book)


finalbook = {**book, **book2}
print("final dictionary :", finalbook)





