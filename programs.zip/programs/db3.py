
import csv
import sys
import pymysql
import os
try:
    # established the connection
    db = pymysql.connect(host ="localhost",port=3306,user='root', password='india@123',database='realestateinfo')
    
    #print(db)
    # created the cursor for navigation
    cursor = db.cursor()
    # define your query
    filename = "realestate.csv"
    if os.path.exists(filename) and os.path.isfile(filename) and os.path.getsize(filename)> 0:
        with open(filename,"r") as fobj:
            # convert file obj to csv object
            reader = csv.reader(fobj)
            for line in reader:
                street = line[0]
                city = line[1]
                
                query = "insert into realestate values('{}','{}')".format(street,city)
                # execute qurey
                cursor.execute(query)
                #print(cursor.rowcount ,"row inserted")
        db.commit()
    else:
        print("file doesn't exist or file is empty")
    
    db.close()

except pymysql.InterfaceError as err:
    print(err)
except pymysql.DatabaseError as err:
    print(err)
except (pymysql.DataError, pymysql.OperationalError) as err:
    print(err)
except Exception as err:
    print("Error occured")
    print(err)
    print(sys.exc_info())