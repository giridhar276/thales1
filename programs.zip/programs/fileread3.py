

import csv
with open("realestate.csv") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        print("street :",line[0])
        print("city   :", line[1])
        print("---------")