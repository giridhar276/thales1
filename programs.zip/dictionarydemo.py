


book  = {"chap1":10 , "chap2":20 ,"chap3":30, "chap1":1000 } 

print(book)

bookinfo={"chap1":[10,"rita","UK"] , "chap2":[20,"Gita","UP"] ,"chap3":{"pages":30} ,3:43  }

print(bookinfo)