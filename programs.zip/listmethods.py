alist = [10,20,30]
alist[2] = 10000
print(alist)
alist.append(40)   # one object

print("After appending :", alist)

alist.extend([40,50,12])   # iterable
print("After extending :", alist)

# list.insert(index, value)
alist.insert(0,1000)
print("After inserting :", alist)
alist.insert(3,400)
print("After inserting :", alist)

alist.pop(0)  # value at 0th index will be removed
print("After pop operaiton :", alist)

alist.remove(400)   # will remove the value directly if existing
                    # or else will an error
print(alist)


alist.sort()   # sorted in ascending order by default
print(alist)

alist.reverse()
print("After reversing :", alist)