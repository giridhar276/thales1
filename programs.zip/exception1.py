try:
    fobj = open("customers1.txt","r")
    for line in fobj:
        # remove whitespaces if having any
        line = line.strip()
        print(line)
    fobj.close()
except Exception as error:
    print("User defined error :",'file not found')
    print("System error  :", error)