# process2.py
print('End of process 2')