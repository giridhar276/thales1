# process3.py
from time import sleep                                                          
                                                                                
sleep(3)                                                                       
print('End of process 3')