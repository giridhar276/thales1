#!/bin/sh

mysql.server start