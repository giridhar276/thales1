# count_lines ref 

## Ref 
- https://www.oreilly.com/library/view/python-cookbook/0596001673/ch04s07.html
- https://stackoverflow.com/questions/845058/how-to-get-line-count-of-a-large-file-cheaply-in-python
- https://stackoverflow.com/questions/9629179/python-counting-lines-in-a-huge-10gb-file-as-fast-as-possible
- https://stackoverflow.com/questions/19001402/how-to-count-the-total-number-of-lines-in-a-text-file-using-python
- http://www.learntosolveit.com/python/files_count_lines_large_file.html
- https://datascienceplus.com/processing-huge-dataset-with-python/
