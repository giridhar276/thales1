

# magic method ( predefined)
print(__name__)