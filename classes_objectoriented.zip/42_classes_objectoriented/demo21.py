class Robot:
    pass

x = Robot()
y = Robot()
 
x.name = "Marvin"
x.build_year = "1979"

y.name = "Caliban"
y.build_year = "1993"
 
print(x.name)
print(y.build_year)
